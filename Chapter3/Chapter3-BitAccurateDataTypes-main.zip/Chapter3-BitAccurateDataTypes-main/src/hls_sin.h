#ifndef __HLS_SIN_H__
#define __HLS_SIN_H__

#include <ap_fixed.h>

void hls_sin(float x[128], const int offset);

#endif
