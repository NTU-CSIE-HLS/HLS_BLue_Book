#ifndef __SIGNED_SHIFT_H__
#define __SIGNED_SHIFT_H__

#include <ap_int.h>

void signed_shift(ap_int<7>* x, bool direc, int amount);

# endif
