#ifndef __UNSIGNED_SHIFT_H__
#define __UNSIGNED_SHIFT_H__

#include <ap_int.h>

void unsigned_shift(ap_uint<7>* x, bool direc, int amount);

# endif
