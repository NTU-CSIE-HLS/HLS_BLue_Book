#ifndef __SLICE_READ_H__
#define __SLICE_READ_H__

#include <ap_int.h>

void slice_read(ap_uint<6> x, ap_uint<3>* out1, ap_uint<3>* out2);

#endif
