#ifndef __SLICE_WRITE_H__
#define __SLICE_WRITE_H__

#include <ap_int.h>

void slice_write(ap_uint<6>* x, ap_uint<3>* w, int base);

#endif
