# Chapter3-BitAccurateDataTypes
Xilinx implementation of Mentor bluebook Chapter3. 

This repo contains the sample codes of mentor bluebook.  
We also implemented some kernel functions of the textbook in xilinx vivado HLS version(src/Shift operation and src/Slice operation).  
And there is a host code test about the precision difference between hls_math and cmath(src/sin_precision_tb.cpp).  
