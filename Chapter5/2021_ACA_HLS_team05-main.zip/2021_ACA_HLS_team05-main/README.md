# 2021 ACA HLS Team 5
Advanced Computer Architecture, 109-2, CSIE 5059, CL Yang
## Course Information
- Course name: Advanced Computer Architecture (ACA) 高等計算機結構
- Course semester: 109-2, 2021 Spring
- Professor name: Chia-Lin Yang 楊佳玲教授
- Special modules: High Level Synthesis, lectured by Jiin Lai 賴瑾
## Team Information
Team 5 游子緒 馬健凱 陳昱行

## Presentation
Google Slides: https://reurl.cc/qmqdqq
<br>
Slides of other groups: https://reurl.cc/OXo1oy
