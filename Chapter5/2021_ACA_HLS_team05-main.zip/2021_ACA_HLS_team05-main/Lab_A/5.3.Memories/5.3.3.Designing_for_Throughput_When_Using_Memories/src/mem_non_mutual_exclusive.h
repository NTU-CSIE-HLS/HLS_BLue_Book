#ifndef __mem_non_mutual_exclusive_H__
#define __mem_non_mutual_exclusive_H__
void accumulate (int din[4],
                int &dout,
                bool &flag0,
                bool &flag1);

#endif
