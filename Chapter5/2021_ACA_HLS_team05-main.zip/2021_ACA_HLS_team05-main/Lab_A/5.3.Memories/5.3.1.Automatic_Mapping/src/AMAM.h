#ifndef __ACCUM_H__
#define __ACCUM_H__


void accumulate4(int din[4], int &dout);

#endif
