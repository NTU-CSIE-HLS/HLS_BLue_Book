#ifndef __ACCUM_H__
#define __ACCUM_H__

void accumulate(int din[4],
                int &dout,
                int threshold,
                bool flag );

#endif
