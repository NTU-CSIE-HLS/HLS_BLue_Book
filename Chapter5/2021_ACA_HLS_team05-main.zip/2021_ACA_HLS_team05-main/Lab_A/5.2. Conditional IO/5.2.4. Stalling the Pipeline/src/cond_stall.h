#ifndef __COND_STALL__
#define __COND_STALL__

void accumulate4(int din[4],
                 int &dout);

#endif
