#ifndef __THROUGHPUT_LIMIT__
#define __THROUGHPUT_LIMIT__

void accumulate (int din[4],
                 int &dout,
                 bool flag[4]);

#endif
