#ifndef __THROUGHPUT_LIMIT_COND__
#define __THROUGHPUT_LIMIT_COND__

void accumulate (int din[4],
                int &dout,
                bool flag[4]);

#endif
