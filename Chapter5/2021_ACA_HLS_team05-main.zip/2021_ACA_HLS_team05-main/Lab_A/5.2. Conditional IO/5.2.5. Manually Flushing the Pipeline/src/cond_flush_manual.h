#ifndef __COND_FLUSH_MANUAL__
#define __COND_FLUSH_MANUAL__

void accumulate(int din[4],
                int &dout,
                bool &ack);

#endif
