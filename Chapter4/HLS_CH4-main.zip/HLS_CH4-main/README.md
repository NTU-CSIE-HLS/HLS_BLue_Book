# HLS CH4 Fundamental of High Level Synthesis

## Topics

### Scheduling
  
  Test HLS scheduling under different clock period.

### Loop Pipelining
  
  Test pipeline with different II.

### Loop Unrolling
  
  Test unrolling with different factor.

### Conditional Loop
  
 Test conditional bound and some alternative solutions.

### Sequential Loop

  Test how dependencies influence the loop optimization.

### Feedback
  
  Test feedback.

## Slide

https://docs.google.com/presentation/d/1T2lAc6PiVM8-Hnsi8vWOhpCBGWpyOdpfHN-sYoFx7gA/edit#slide=id.gcf1bdc5ea4_2_35
