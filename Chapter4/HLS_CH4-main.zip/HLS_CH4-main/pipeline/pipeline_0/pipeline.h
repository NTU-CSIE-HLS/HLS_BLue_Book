#ifndef __PIPELINE_H__
#define __PIPELINE_H__

#define N (int)2

void top(int a[], int b[], int c[], int dout[]);

#endif

