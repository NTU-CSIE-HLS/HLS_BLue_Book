#include "pipeline.h"

void sub(int a, int b, int c, int *dout){
#pragma HLS inline
	int t;
	t = a + b;
	*dout = t + c; 
}

void top(int a[N], int b[N], int c[N], int dout[N]){	
	MAIN_LOOP: for(int i = 0; i < N; i++){
//#pragma HLS pipeline II=1
		sub(a[i], b[i], c[i], &dout[i]);
	}
}
