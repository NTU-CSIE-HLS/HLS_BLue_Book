#include <iostream>
#include "pipeline.h"

using namespace std;

int main(){
	int pass = 1;
	int a[N], b[N], c[N], dout[N];

	for(int i = 0; i < N; i++){
		a[i] = i;
		b[i] = i;
		c[i] = i;
		top(a, b, c, dout);
		if(dout[i] != (a[i] + b[i] + c[i])){
			pass = 0;
		}
	}

	if(!pass){
		cout << "Test failed!" << endl;
		return 1;
	}

	cout << "Test passed!" << endl;
	return 0;
}

