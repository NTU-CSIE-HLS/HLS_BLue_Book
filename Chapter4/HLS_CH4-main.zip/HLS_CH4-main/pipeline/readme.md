# loop pipelining

This demo test the effect of loop pipelining on resource and time.

The tested target is `pipeline.cpp:top()` which contains a loop calling `pipeline.cpp:sub()` in each iteration.

`pipeline_0` : no pipeline

`pipeline_1` : pipeline with II = 1

