#include "schedule.h"

void top(int a, int b, int c, int *dout){
	int t;
	t = a + b;
	*dout = t + c; 
}

