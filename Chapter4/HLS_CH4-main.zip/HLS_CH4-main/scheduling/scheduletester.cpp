#include <iostream>
#include "schedule.h"

using namespace std;

int main(){
	int pass = 1;
	int a, b, c, dout;

	for(int i = 0; i < 10; i++){
		a = i;
		b = i;
		c = i;
		top(a, b, c, &dout);
		if(dout != (a + b + c)){
			pass = 0;
		}
	}

	if(!pass){
		cout << "Test failed!" << endl;
		return 1;
	}

	cout << "Test passed!" << endl;
	return 0;
}

