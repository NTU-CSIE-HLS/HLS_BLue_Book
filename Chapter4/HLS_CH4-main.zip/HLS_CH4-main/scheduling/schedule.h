#ifndef __SCHEDULE_H__
#define __SCHEDULE_H__

void top(int a, int b, int c, int *dout);

#endif

