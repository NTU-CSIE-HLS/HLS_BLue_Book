# Scheduling

This directory demonstrates the effect of clock period to the scheduling in synthesis.
 
Set different clock period to see the scheduling results.
