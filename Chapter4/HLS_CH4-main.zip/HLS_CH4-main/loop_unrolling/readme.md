# loop unrolling

The following directory test the effect of unrolling under different factor value to a loop with 4 iteration :

`unrolling_0` : no unrolling

`unrolling_1` : unrolling with factor 2

`unrolling_2` : unrolling with factor 4 

> In `unrolling.cpp`,  comments are the alternatives which have the same effects on latency and resource utilization.
