#include <iostream>
#include "unrolling.h"

using namespace std;

int main(int argc, char *argv[]){
    int pass = 1;

    for(int i = 1; i < 10; i++){
        for(int j = 1; j < 10; j++){
			int din[4] = {i, j, i, j};
			int dout;
            unrolling(din, &dout);
            if(dout != (i + j + i + j)) {
                pass = 0;
            }
        }
    }
    if(!pass){
        cout << "Test failed!" << endl;
        return 1;
    }

    cout << "Test passed!" << endl;
    return 0;
}

