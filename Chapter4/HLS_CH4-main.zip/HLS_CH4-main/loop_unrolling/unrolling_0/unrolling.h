#ifndef __UNROLLING_H__
#define __UNROLLING_H__

void unrolling(int din[4], int *dout);

#endif

