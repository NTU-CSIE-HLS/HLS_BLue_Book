#include "unrolling.h"

void unrolling(int din[4], int *dout){
	int acc = 0;

	ACCU: for(int i = 0; i < 4; i++){
		acc += din[i];
	}

	*dout = acc;
}
