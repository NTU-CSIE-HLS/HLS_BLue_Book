#include "sequential.h"

void sequential(int din0[4], int din1[4],int *dout0, int *dout1){
#pragma HLS array_partition variable=din0 block factor=4
#pragma HLS array_partition variable=din1 block factor=4
	int acc0 = 0;
	int acc1 = 0;

	ACCUM0: for(int i = 0; i < 4; i++){
		acc0 += din0[i];
	}
	acc1 = acc0;
	ACCUM1: for(int i = 0; i < 4; i++){
		acc1 += din1[i];
	}

	*dout0 = acc0;
	*dout1 = acc1;
}

void top(int din0[4], int din1[4], int *dout0, int *dout1){
	MAIN_LOOP: for(int i = 0; i < N; i++){
#pragma HLS pipeline II=1
		sequential(din0, din1, dout0, dout1);
	}
}
