#include <iostream>
#include "sequential.h"

using namespace std;

int main(int argc, char *argv[]){
	int pass = 1;
	int din0[4], din1[4], dout0, dout1;

	for(int i = 0; i < 10; i++){
		for(int j = 0; j < 10; j++){
			int acc0 = 0, acc1 = 0;
			for(int k = 0; k < 4; k++){
				din0[k] = i % 4;
				din1[k] = j % 4;
				acc0 += din0[k];
				acc1 += din1[k];

			}
			top(din0, din1, &dout0, &dout1);

			if(dout0 != acc0 || dout1 != acc1){
				pass = 0;
			}
		}
	}

	if(!pass){
		cout << "Test failed!" << endl;
		return 1;
	}

	cout << "Test passed!" << endl;
	return 0;
}


