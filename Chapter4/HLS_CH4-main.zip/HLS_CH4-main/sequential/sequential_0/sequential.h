#ifndef __SEQUENTIAL_H__
#define __SEQUENTIAL_H__

#define N (int)2

void top(int din0[], int din1[],int *dout0, int *dout1);

#endif


