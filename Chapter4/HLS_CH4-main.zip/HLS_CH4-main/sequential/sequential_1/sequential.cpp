#include "sequential.h"

void sequential(int din0[4], int din1[4],int *dout0, int *dout1){
	int acc0 = 0;
	int acc1 = 0;

	ACCUM0: for(int i = 0; i < 4; i++){
#pragma HLS LOOP_MERGE
		acc0 += din0[i];
	}
	acc1 = acc0;
	ACCUM1: for(int i = 0; i < 4; i++){
#pragma HLS LOOP_MERGE
		acc1 += din1[i];
	}

	*dout0 = acc0;
	*dout1 = acc1;
}

void top(int din0[4], int din1[4], int *dout0, int *dout1){
	MAIN_LOOP: for(int i = 0; i < N; i++){
		sequential(din0, din1, dout0, dout1);
	}
}
