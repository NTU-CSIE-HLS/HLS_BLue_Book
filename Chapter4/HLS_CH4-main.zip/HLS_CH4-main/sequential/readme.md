# sequential loop

This directory demonstrates how dependencies between loops influence the loop merge results.

`sequential_0` : no dependency and HLS optimization will merge loops, where loop `ACCU0` and `ACCU1` are merged.

`sequential_1` : with dependency and HLS optimization cannot merge loops, where loop `ACCU1` is executed after loop `ACC0` finished. 

`sequential_2` : with dependency and pipeline MAIN_LOOP with II=1

`sequential_3` : another implementation with dependency and pipeline MAIN_LOOP with II=1

> array partition is implement to avoid the infeasibility due to the read array operations

> In both `sequential_2` and `sequential_3`, MAIN_LOOP can be pipelined with II=1 under HLS optimization, which is diffferent from the contents in textbook.
