# conditional loop

This directory demonstrates the effects of conditional bound to a loop. 

`conditional_0` : loop with variable bound, and the value of bound is limited by `ap_int<3>` type

`conditional_1` : loop with variable iterations and upper bound 

`conditional_2` : loop with variable iterations and upper bound 

> `conditional_1` have higher latency but use less hardware resource than `conditional_2`.
