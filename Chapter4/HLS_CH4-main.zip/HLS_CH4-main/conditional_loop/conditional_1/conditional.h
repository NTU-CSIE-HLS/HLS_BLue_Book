#ifndef __CONDITIONAL_H__
#define __CONDITIONAL_H__

void condition(int din[4], int *dout, int ctrl);

#endif

