#include "conditional.h"

void condition(int din[4], int *dout, int ctrl){
	int acc = 0;
	ACCUM: for(int i = 0; i < 4; i++){
		if(i >= ctrl){
			break;
		}
		acc += din[i];
	}
	*dout = acc;
}
