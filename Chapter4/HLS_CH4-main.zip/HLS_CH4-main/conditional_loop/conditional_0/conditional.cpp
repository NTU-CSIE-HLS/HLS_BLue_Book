#include "conditional.h"

void condition(int din[4], int *dout, ap_int<3> ctrl){
	int acc = 0;
	ACCUM: for(int i = 0; i < ctrl; i++){
		acc += din[i];
	}
	*dout = acc;
}

