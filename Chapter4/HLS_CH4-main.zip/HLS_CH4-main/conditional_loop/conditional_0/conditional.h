#ifndef __CONDITIONAL_H__
#define __CONDITIONAL_H__
#include <ap_int.h>

void condition(int din[4], int *dout, ap_int<3> ctrl);

#endif

