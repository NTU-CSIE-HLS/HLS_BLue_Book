#include <iostream>
#include "conditional.h"

using namespace std;

int main(int argc, char *argv[]){
    int pass = 1;

    for(int i = 1; i < 10; i++){
        for(int j = 1; j < 10; j++){
            int din[4] = {i, j, i, j};
            int dout;
			int acc = 0;
			unsigned int ctrl = i * j % 4;
			for(int k = 0; k < ctrl; k++){
				acc += din[k];
			}
			condition(din, &dout, ctrl);
            if(dout != acc){
                pass = 0;
            }
        }
    }
    if(!pass){
        cout << "Test failed!" << endl;
        return 1;
    }

    cout << "Test passed!" << endl;
    return 0;
}

