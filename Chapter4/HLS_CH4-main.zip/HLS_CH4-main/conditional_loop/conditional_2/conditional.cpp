#include "conditional.h"

void condition(int din[4], int *dout, int ctrl){
	int acc = 0;
	ACCUM: for(int i = 0; i < 4; i++){
		acc += din[i];
		if(i >= ctrl - 1){
			break;
		}
	}
	*dout = acc;
}
