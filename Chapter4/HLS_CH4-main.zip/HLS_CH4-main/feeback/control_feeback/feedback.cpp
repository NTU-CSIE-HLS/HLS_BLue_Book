#include "feedback.h"

void control(int din[8][8], int dout[8], ap_int<4> x_size, ap_int<4> y_size) {
	int acc;
	X: for (int x = 0; x < 8; x++) {
		acc = 0;
		Y: for (int y = 0; y < 8; y++) {
			acc += din[x][y];
			dout[x] = acc;
			if (y == y_size - 1)
				break;
		}
		if (x == x_size - 1)
			break;
	}

	return;
}
