#include <iostream>
#include "feedback.h"
using namespace std;

int main() {
	const int mask = 87;
	int input[8][8], output[8], sum[8];
	ap_int<4> x_size = 6, y_size = 6;

	cout << "Test started..." << endl;
	for (int i = 0; i < x_size; i++) {
		sum[i] = 0;
		for (int j = 0; j < y_size; j++) {
			input[i][j] = i*mask + j;
			sum[i] += input[i][j];
		}
	}

	cout << "-----------------" << endl;
	int pass = 1;
	control(input, output, x_size, y_size);
	for (int i = 0; i < x_size; i++) {
		if (output[i] != sum[i])
			pass = 0;
	}
	if (!pass) {
		cout << "Test failed!" << endl;
		return 1;
	}
	cout << "Test passed!" << endl;
	return 0;
}
