#ifndef __CONTROL__
#define __CONTROL__

#include <ap_int.h>

void control(int[][8], int[8], ap_int<4>, ap_int<4>);

#endif
