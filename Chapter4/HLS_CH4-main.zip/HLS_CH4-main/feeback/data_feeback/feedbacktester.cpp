#include <iostream>
#include "feedback.h"
using namespace std;

int main(int argc, char *argv[]) {

	int a = 2, b = 1;
	int sum = 0;
	int flag = 1;

	cout << "Test started..." << endl;
	for (int i = 0; i < 10; i++) {
		sum *= weight;
		sum += offset;

		int res = 0;
		accumulate(weight, offset, &res);
		if (res != sum) {
			flag = 0;
		}
	}

	cout << "-------------------" << endl;
	if (!flag) {
		cout << "Test failed!" << endl;
		return 1;
	}
	cout << "Test passed!" << endl;

	return 0;
}
