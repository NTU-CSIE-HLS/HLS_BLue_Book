#include "feedback.h"

// original version
/*
void accumulate(int a, int b, int *dout) {
	static int acc = 0;
	int tmp = acc * a;
	acc = tmp + b;
	*dout = acc;

	return;
}
*/

// delay version
void accumulate(int a, int b, int *dout) {
	static int acc = 0;
	static int acc_old0;
	static int acc_old1;

	int tmp0 = acc_old1 * a;
	acc = tmp0 + b;
	acc_old1 = acc_old0;
	acc_old0 = acc;
	*dout = acc;

	return;
}
