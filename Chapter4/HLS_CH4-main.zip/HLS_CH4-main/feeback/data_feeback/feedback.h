#ifndef __FEEDBACK__
#define __FEEDBACK__

void accumulate(int, int, int*);

#endif
