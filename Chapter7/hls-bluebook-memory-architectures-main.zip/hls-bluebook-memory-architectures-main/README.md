# hls-bluebook-memory-architectures
