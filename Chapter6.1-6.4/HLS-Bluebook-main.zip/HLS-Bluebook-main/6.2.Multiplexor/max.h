#ifndef __MAX__
#define __MAX__

#define N_REGS 8

void max(int din[N_REGS], int &dout);

void max_algorithmic(int din[N_REGS], int &dout);

#endif

