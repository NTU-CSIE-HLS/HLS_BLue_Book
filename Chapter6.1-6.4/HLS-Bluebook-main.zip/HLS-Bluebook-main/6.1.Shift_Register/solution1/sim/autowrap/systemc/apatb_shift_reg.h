// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================

extern void AESL_WRAP_shift_reg (
signed char din0,
int din1,
signed char load_data[12],
signed char dout0[12],
int dout1[4],
bool srst,
bool load,
bool en,
ap_uint<3> select);
