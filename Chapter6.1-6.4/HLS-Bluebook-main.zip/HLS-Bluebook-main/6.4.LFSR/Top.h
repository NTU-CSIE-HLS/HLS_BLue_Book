void top(ap_uint<8> load_data,
         bool ld,
         ap_uint<8> &dout);
