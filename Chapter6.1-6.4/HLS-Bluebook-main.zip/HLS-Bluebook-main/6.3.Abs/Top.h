#include "Abs.h"

ABSTYPE top(ABSTYPE val, int mode);
