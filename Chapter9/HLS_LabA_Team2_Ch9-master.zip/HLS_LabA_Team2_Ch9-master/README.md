ppt link:

https://docs.google.com/presentation/d/1oEbNO0Q1caKwZboVUHkwLSVxn3nW6_H6Fss4HYiR3AA/edit?usp=sharing